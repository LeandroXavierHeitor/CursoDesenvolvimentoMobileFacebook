package com.somostops.fenixnavigator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        wbvWeb.settings.javaScriptEnabled = true





        btnPesquisar.setOnClickListener {

            val url = edtPesquisa.text.toString()
            if(url.isNotEmpty()){
                wbvWeb.loadUrl("https://www."+url)

            }
            else{
                Toast.makeText(this@MainActivity, "DIGITE UMA URL VÁLIDA", Toast.LENGTH_LONG).show()
            }


        }
        btnIr.setOnClickListener {
            wbvWeb.goForward()
        }
         btnVoltar.setOnClickListener{
            wbvWeb.goBack()


         }
        btnAtualizar.setOnClickListener {

            wbvWeb.reload()


        }


    }

}


