﻿package br.com.gabriel.persistenciadedados

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        //declarando a preferencia

        val minhaPreferencia = getSharedPreferences("minhaPreferencia", Context.MODE_PRIVATE)
        val meuEditor = minhaPreferencia.edit()

        //gravando a mensagem no XML

    btnGravar.setOnClickListener {

        //entrada de dados
        val mensagem = edtMensagem.text.toString().trim()
        if(mensagem.isNotEmpty()){
            meuEditor.putString("mensagem", mensagem).commit()
            edtMensagem.text.clear()
            Toast.makeText(this,"Sucesso.", Toast.LENGTH_LONG).show()
            }
        else{
            //Apresentar msg pro user
            Toast.makeText(this@MainActivity, "DIGITE UMA MENSAGEM!", Toast.LENGTH_LONG).show()

        }


    }


    btnRecuperar.setOnClickListener {

      txvResultado.text = minhaPreferencia.getString("mensagem","ERRO!" )


    }












    }
}
