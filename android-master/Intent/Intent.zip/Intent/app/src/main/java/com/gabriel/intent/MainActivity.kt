package com.gabriel.intent

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // criando a ação de clique do botao
        btnEnviar.setOnClickListener {

            //entrada de dados
            val nome = edtNome.text.toString().trim()
            if(nome.isNotEmpty()){
                // criando o objeto
                val intent = Intent(this, Tela2Activity::class.java)

                //executar ação
                startActivity(intent)
            }
            else{
                //Apresentar msg pro user
                Toast.makeText(this@MainActivity, "DIGITE UM NOME SUA ANTA!",Toast.LENGTH_LONG).show()
            }


        }


    }
}
